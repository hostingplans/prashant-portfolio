# Minecraft Server Developer Portfolio

A modern, responsive portfolio template designed for Minecraft server managers, developers, administrators, and technical creators.

Dark charcoal design with a red accent, a server-dashboard aesthetic, and a single configuration file for everything you need to change.

## Made by Electro

The original template was designed and developed by **Electro** and is provided as a reusable template / source-code project. You are free to customise it with your own name, projects, services and links — a small "Made by Electro" credit lives in the footer.

## Features

- Single-file customisation (`src/config/site.ts`) — name, bio, skills, services, projects, experience, stats, testimonials, contact, SEO
- Sticky navbar with scroll state and an animated mobile menu
- Hero section with an editable technical status panel
- About section with a decorative terminal component (typing effect)
- Categorised skill cards
- Service cards with expandable details and optional pricing
- Filterable project grid with a full case-study modal (overview, problem, solution, architecture, challenges, results, screenshots, links)
- Vertical experience timeline
- Simulated server dashboard: status, players, TPS, CPU, RAM, disk, uptime, version, proxy, plus a dependency-free sparkline chart
- Technical stack, statistics and optional testimonials sections
- Contact section with a validated frontend-only form
- Scroll-reveal animations that respect `prefers-reduced-motion`
- Semantic HTML, keyboard navigation, focus states, accessible modal
- SEO: title, description, Open Graph, Twitter, canonical, `robots.txt`, `sitemap.xml`

## Screenshots

### Home and about

The opening view keeps the portfolio focused: who you are, what you work on, and a quick server-style overview without turning the page into a generic landing screen.

![Portfolio home and about sections](docs/screenshots/homepage.png)

### Project showcase

Example work is laid out like a practical server portfolio, with filters, familiar tooling, and direct links into each case study.

![Filterable Minecraft server project showcase](docs/screenshots/projects.png)
<!-- ![Projects](docs/screenshot-projects.png) -->

## Tech stack

- React 19 + TypeScript
- TanStack Start / TanStack Router
- Tailwind CSS v4 (design tokens in `src/styles.css`)
- lucide-react icons
- Vite

No animation library, no chart library — the chart is inline SVG and the animations are CSS.

## Project structure

```text
src/
  config/
    site.ts              <- EDIT THIS: all site content
  components/
    site/
      primitives.tsx     Reveal / Section / SectionHeading / PixelMark
      Navbar.tsx
      Hero.tsx
      About.tsx
      Terminal.tsx
      Skills.tsx
      Services.tsx
      Projects.tsx       Grid + case-study modal
      Dashboard.tsx      Demo server dashboard
      Experience.tsx
      StackAndStats.tsx  Stats / TechStack / Testimonials
      Contact.tsx
      Footer.tsx
    ui/                  shadcn-style primitives (optional)
  routes/
    __root.tsx           Document shell, fonts, base metadata
    index.tsx            The page — section order lives here
  styles.css             Theme tokens, utilities, animations
public/
  robots.txt
  sitemap.xml
  favicon.ico
```

## Installation

```bash
git clone <your-repo-url>
cd <your-repo>
npm install
```

## Local development

```bash
npm run dev      # start the dev server
npm run build    # production build
npm run preview  # preview the production build
npm run lint     # lint
```

## Customization

Everything lives in **`src/config/site.ts`**. You should not need to touch a component to change content.

### Name, role, bio

```ts
export const siteConfig = {
  name: "Your Name",
  initials: "YN",
  role: "Minecraft Server Manager & Developer",
  location: "Remote · UTC+1",
  available: true,
  tagline: "I build, configure, optimize, and maintain Minecraft servers…",
  about: { intro: "…", paragraphs: ["…"], philosophy: "…" },
};
```

`role` is split on the `&` in the hero, so the second half is accented. Keep one `&` for that effect.

### Adding projects

Append to the `projects` array:

```ts
{
  id: "my-server",
  name: "My Server",
  description: "One line about it.",
  category: "Server",              // Server | Plugin | Network | Website | Infrastructure
  status: "Live",                  // Live | In Progress | Archived | Demo
  date: "2026",
  tech: ["Paper", "Java", "MySQL"],
  image: "https://…/banner.jpg",   // optional
  links: { demo: "https://…", github: "https://…" },
  caseStudy: {
    overview: "…",
    problem: "…",
    solution: "…",
    architecture: ["…"],
    challenges: ["…"],
    results: ["…"],
    screenshots: [{ src: "https://…", alt: "Dashboard" }],
  },
}
```

Any omitted field is simply not rendered. Filter categories come from `projectFilters` in the same file.

### Adding skills

```ts
skills: [
  { category: "Server Management", items: ["Paper", "Velocity", "Pterodactyl"] },
]
```

Delete anything you don't actually work with — the shipped list is only an example.

### Services and pricing

Set `showPricing: false` to hide every price at once, or edit each service's `price`, `description` and `details`.

### Changing colors

All colours are tokens in `src/styles.css`. To change the accent, edit three values in `:root`:

```css
--primary: oklch(0.57 0.203 24);        /* red */
--primary-hover: oklch(0.62 0.21 24);
--ring: oklch(0.57 0.203 24);
```

Other tokens you may want to touch: `--background`, `--surface`, `--surface-2`, `--border`, `--border-strong`, `--foreground`, `--muted-foreground`, `--radius`, `--shadow-panel`.

A light theme is included: add `class="light"` to the `<html>` element in `src/routes/__root.tsx`. The design is built dark-first, so the dark theme is recommended.

### Changing fonts

Fonts are loaded with a `<link>` in `src/routes/__root.tsx` and mapped in `src/styles.css` (`--font-display`, `--font-sans`, `--font-mono`).

### Changing social links

```ts
contact: {
  email: "you@example.com",
  discord: "yourname",
  discordInvite: "https://discord.gg/…",
  github: "https://github.com/…",
}
```

### Changing SEO information

```ts
seo: {
  title: "Your Name — Minecraft Server Manager & Developer",
  description: "…",
  canonical: "https://yourdomain.com",
  ogImage: "https://yourdomain.com/og.png", // absolute URL, or leave empty
}
```

Also update `public/robots.txt` and `public/sitemap.xml` with your domain, and replace `public/favicon.ico`.

### Contact form

The form validates on the frontend only — nothing is sent. To make it real, submit the values in `Contact.tsx` to your own endpoint or an email service (Resend, Formspree, EmailJS, …).

### Server dashboard

`dashboard` in the config holds demo values. To show live data, fetch your own status endpoint and pass the result into `Dashboard.tsx` instead of the config object.

## Deployment

### Vercel

1. Push the repo to GitHub.
2. Import the project on Vercel.
3. Build command `npm run build`. The framework is auto-detected.

### Cloudflare Pages / Workers

1. Connect the repository.
2. Build command `npm run build`.
3. Deploy the generated server output (the template targets an edge runtime).

### GitHub Pages

GitHub Pages only serves static files, so it requires a static/prerendered build of the site. The template renders on a server runtime by default — Vercel or Cloudflare is the smoother path.

### Environment variables

None are required. If you add an email service or API, put its keys in `.env` and read them server-side only.

## Customization checklist

- [ ] `name`, `initials`, `role`, `location`, `tagline`
- [ ] `about` text and `philosophy`
- [ ] `heroPanel` and `stats` values
- [ ] `skills`
- [ ] `services` (and `showPricing`)
- [ ] `projects` — remove all demo entries
- [ ] `experience` — remove placeholder roles
- [ ] `dashboard` demo numbers
- [ ] `testimonials` (or set `enabled: false`)
- [ ] `contact` details
- [ ] `seo`, `robots.txt`, `sitemap.xml`, favicon
- [ ] accent colour in `src/styles.css`

## Contributing

Issues and pull requests are welcome. Keep changes focused, match the existing formatting (`npm run format`), and make sure `npm run lint` and `npm run build` pass.

## License

MIT — free for personal and commercial use. Attribution is appreciated but not required beyond the footer credit.

## Credits

`Designed and developed by Electro.`

- Website / GitHub / portfolio: _add your link here_ (`footer.creditUrl` in `src/config/site.ts`)

Icons by [Lucide](https://lucide.dev). No Minecraft assets, logos or trademarks are included; this template is unofficial and not affiliated with Mojang or Microsoft.

## Disclaimer

This is a portfolio template. Example projects, statistics, testimonials, experience, and other content are placeholders and should be replaced with the user's real information.
