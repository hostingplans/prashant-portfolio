/**
 * =============================================================================
 *  SITE CONFIGURATION — EDIT THIS FILE TO MAKE THE TEMPLATE YOURS
 * =============================================================================
 *
 *  Everything visible on the website is defined here: your name, bio, skills,
 *  services, projects, experience, stats, testimonials, links and SEO text.
 *  You should not need to open any component file to customise the site.
 *
 *  NOTE: all numbers/text below are PLACEHOLDERS. Replace them with your own
 *  real information before publishing.
 *
 *  Template designed and developed by Electro.
 * =============================================================================
 */

import avatarAsset from "@/assets/avatar.png.asset.json";
import projectDeploy from "@/assets/project-deploy.jpg";
import projectMinigame from "@/assets/project-minigame.jpg";
import projectNetwork from "@/assets/project-network.jpg";
import projectPlugin from "@/assets/project-plugin.jpg";
import projectStatusSite from "@/assets/project-status-site.jpg";
import projectSurvival from "@/assets/project-survival.jpg";

export type ProjectCategory = "Server" | "Plugin" | "Network" | "Website" | "Infrastructure";

export interface Project {
  id: string;
  name: string;
  /** Short one-liner shown on the card. */
  description: string;
  category: ProjectCategory;
  status: "Live" | "In Progress" | "Archived" | "Demo";
  date: string;
  tech: string[];
  /** Optional banner image URL. Leave empty to use the generated pattern. */
  image?: string;
  links?: { demo?: string; github?: string };
  /** Long-form case study. Any field you leave out is simply not rendered. */
  caseStudy?: {
    overview?: string;
    problem?: string;
    solution?: string;
    architecture?: string[];
    challenges?: string[];
    results?: string[];
    screenshots?: { src: string; alt: string }[];
  };
}

export const siteConfig = {
  /** ---------------------------------------------------------------- IDENTITY */
  name: "Prashant Thapa",
  initials: "PT",
  role: "Minecraft Developer & Hosting Founder",
  location: "Nepal · Available Worldwide",
  available: true,
  availabilityLabel: "Open to Minecraft Projects",
  avatar: avatarAsset.url,
  tagline:
    "I build Minecraft communities, configure cross-play servers, and create practical hosting solutions through SKYHOST & STUDIO.",

  /** ------------------------------------------------------------------- ABOUT */
  about: {
    intro:
      "I'm a Minecraft server creator and developer focused on building welcoming multiplayer experiences, configuring plugins, and helping communities bring their server ideas to life.",
    paragraphs: [
      "My work spans server setup, plugin and configuration work, Java–Bedrock cross-play, community features, and the practical details that keep a Minecraft server organized. My current projects include PHOENIX MC and NEXORA SMP.",
      "I’m also building SKYHOST & STUDIO, a hosting and server-setup brand for Minecraft communities. The goal is to make launching and managing a server more approachable, from the initial setup to maps, scripts, configs, and models.",
    ],
    philosophy:
      "Build for the players first: make the experience clear, keep the setup maintainable, and improve it one step at a time.",
  },

  /** --------------------------------------------------------------- HERO CARD */
  heroPanel: [
    { label: "Main Focus", value: "Minecraft", accent: true },
    { label: "Community Project", value: "PHOENIX MC" },
    { label: "Hosting Brand", value: "SKYHOST & STUDIO" },
    { label: "Cross-play", value: "Java + Bedrock" },
  ],

  /** ------------------------------------------------- STATS */
  stats: [
    { value: "02+", label: "Featured Server Projects" },
    { value: "Java + Bedrock", label: "Cross-play Focus" },
    { value: "360°", label: "Server Setup Support" },
    { value: "SH&S", label: "Hosting Brand" },
  ],

  /** ------------------------------------------------------------------ SKILLS */
  skills: [
    { category: "Minecraft Servers", items: ["Paper", "Spigot", "Minecraft Java", "Minecraft Bedrock", "GeyserMC", "Floodgate"] },
    { category: "Configuration", items: ["Plugin Configuration", "Permissions", "Economy Setup", "Server Optimization", "Backups", "Troubleshooting"] },
    { category: "Community & Gameplay", items: ["Survival SMP", "PvP", "Crates & Ranks", "Discord Integration", "Server Branding", "World Setup"] },
    { category: "Hosting & Tools", items: ["Linux", "Docker", "Pterodactyl", "Nginx", "Cloudflare", "GitHub"] },
  ],

  /** ---------------------------------------------------------------- SERVICES */
  showPricing: false,
  services: [
    { icon: "server", title: "Minecraft Server Setup", description: "Set up and organize a Minecraft server around your community and gameplay goals.", details: ["Paper server setup and core configuration", "Gameplay, permissions, ranks, and economy configuration", "Guidance for launch and ongoing maintenance"] },
    { icon: "plug", title: "Plugin & Config Setup", description: "Configure plugins and connect the features your server needs.", details: ["Plugin installation and configuration", "Economy, crates, ranks, teams, and survival features", "Troubleshooting conflicts and configuration issues"] },
    { icon: "network", title: "Java + Bedrock Cross-play", description: "Configure cross-play using GeyserMC and Floodgate where supported by your setup.", details: ["GeyserMC and Floodgate configuration", "Port and connection setting checks", "Help diagnosing Java–Bedrock connection issues"] },
    { icon: "wrench", title: "Server Maintenance", description: "Practical help with server updates, backups, and common technical issues.", details: ["Backup and restart planning", "Plugin and version compatibility checks", "Performance and configuration troubleshooting"] },
    { icon: "code", title: "Maps, Scripts & Models", description: "Minecraft setup support for maps, scripts, configs, and models through SKYHOST & STUDIO.", details: ["Map and server setup assistance", "Skript and configuration support", "Models and custom server presentation assets"] },
    { icon: "gauge", title: "Hosting Guidance", description: "Help planning a hosting setup and choosing a practical control-panel workflow.", details: ["Panel and deployment planning", "Domain and connection setup guidance", "Guidance for scaling a small Minecraft community"] },
  ],

  /** ---------------------------------------------------------------- PROJECTS */
  projects: [
    {
      id: "phoenix-mc",
      image: projectSurvival,
      name: "PHOENIX MC — Season 2",
      description: "A survival and PvP Minecraft community with seasonal branding, ranks, crates, and community launch events.",
      category: "Server",
      status: "In Progress",
      date: "2026",
      tech: ["Paper", "Minecraft 1.21.11", "GeyserMC", "Floodgate", "Plugins"],
      caseStudy: {
        overview: "PHOENIX MC is a Minecraft server project focused on survival gameplay, PvP, and a recognizable seasonal identity.",
        solution: "The project includes server feature configuration, rank and crate presentation, launch announcements, and planning for Java and Bedrock access.",
        architecture: ["Paper-based Java server", "Cross-play planning with GeyserMC and Floodgate", "Plugin-driven survival and PvP features"],
        challenges: ["Keeping plugin configurations consistent", "Making launch information and server features easy for players to understand"],
        results: ["A consistent PHOENIX MC Season 2 identity", "A structured set of server features and community launch materials"],
      },
    },
    {
      id: "nexora-smp",
      image: projectNetwork,
      name: "NEXORA SMP",
      description: "A survival SMP project with Java–Bedrock compatibility, economy, claims, teams, and community plugins.",
      category: "Network",
      status: "In Progress",
      date: "2026",
      tech: ["Paper 1.21.11", "GeyserMC", "Floodgate", "EconomyShopGUI", "GriefPrevention"],
      caseStudy: {
        overview: "NEXORA SMP brings together survival gameplay and community features in one main spawn experience.",
        solution: "The setup has included cross-play support, economy and shop plugins, land protection, and work on team and gameplay systems.",
        architecture: ["Paper server", "GeyserMC and Floodgate for Bedrock compatibility", "Plugin-based economy and land protection"],
        challenges: ["Maintaining compatibility between plugins and server versions", "Tuning gameplay features without fragmenting the player experience"],
      },
    },
    {
      id: "skyhost-studio",
      image: projectDeploy,
      name: "SKYHOST & STUDIO",
      description: "A developing Minecraft hosting and server-setup brand offering hosting guidance and setup-related services.",
      category: "Infrastructure",
      status: "In Progress",
      date: "2026",
      tech: ["Ubuntu", "Docker", "Nginx", "Linux", "Minecraft Hosting"],
      caseStudy: {
        overview: "SKYHOST & STUDIO is the hosting brand being developed alongside personal Minecraft server projects.",
        solution: "The project explores VPS-based infrastructure, container testing, panel planning, and domain and connection setup.",
        architecture: ["Ubuntu VPS environment", "Docker-based service testing", "Planning for a web-based hosting panel"],
        challenges: ["Verifying external port forwarding and connectivity", "Preparing a dependable, manageable setup for future customers"],
      },
    },
    {
      id: "java-bedrock-crossplay",
      image: projectPlugin,
      name: "Java + Bedrock Cross-play Setup",
      description: "Configuration and troubleshooting work for GeyserMC and Floodgate to help Bedrock players join Java servers.",
      category: "Plugin",
      status: "In Progress",
      date: "2026",
      tech: ["GeyserMC", "Floodgate", "Paper", "Bedrock Edition", "Java Edition"],
      caseStudy: {
        overview: "Cross-play setup work focused on connecting Bedrock players to a Java server where the server configuration supports it.",
        solution: "The work includes reviewing Geyser and Floodgate configuration, listening ports, and connection troubleshooting.",
        challenges: ["Making sure the Bedrock listener and Java server settings are not confused", "Checking the hosting provider's port forwarding requirements"],
      },
    },
    {
      id: "discord-community-branding",
      image: projectMinigame,
      name: "Minecraft Community & Discord Branding",
      description: "Server announcements, rank and crate messages, Discord community structure, and launch assets for Minecraft projects.",
      category: "Website",
      status: "In Progress",
      date: "2026",
      tech: ["Discord", "Community Management", "Minecraft Formatting", "Branding"],
      caseStudy: {
        overview: "Community presentation work that supports Minecraft server launches and ongoing player communication.",
        solution: "Includes concise launch announcements, server branding direction, Discord categories and applications, and in-game colored text configuration.",
      },
    },
  ] as Project[],

  /** -------------------------------------------------------------- EXPERIENCE */
  experience: [
    { role: "Minecraft Server Creator & Administrator", org: "PHOENIX MC", period: "Current Project", description: "Developing and configuring a survival and PvP community, including seasonal branding, server features, and launch communications.", responsibilities: ["Configure server plugins and gameplay features", "Prepare rank, crate, and launch presentation", "Troubleshoot server configuration and cross-play"], tech: ["Paper", "GeyserMC", "Floodgate", "Minecraft Plugins"] },
    { role: "Minecraft Server Creator", org: "NEXORA SMP", period: "Current / Previous Project", description: "Working on a survival SMP with economy, claims, and Java–Bedrock compatibility.", responsibilities: ["Configure economy and protection plugins", "Review cross-play configuration", "Plan and tune community gameplay features"], tech: ["Paper", "EconomyShopGUI", "GriefPrevention", "GeyserMC"] },
    { role: "Founder / Builder", org: "SKYHOST & STUDIO", period: "Building", description: "Developing a Minecraft hosting and server-setup brand with a focus on practical tools and services for server owners.", responsibilities: ["Explore VPS and container infrastructure", "Plan a web-based hosting panel workflow", "Develop service and community branding"], tech: ["Ubuntu", "Docker", "Nginx", "Minecraft Hosting"] },
  ],

  /** ------------------------------------------- SERVER DASHBOARD (DEMO DATA) */
  dashboard: {
    serverName: "phoenix-mc.example",
    version: "Paper 1.21.11",
    proxy: "Java + Bedrock · Cross-play setup",
    status: "Online",
    uptime: "Portfolio preview",
    players: { online: 24, max: 100 },
    tps: 20.0,
    cpu: 38,
    ram: { used: 5.8, total: 8 },
    disk: { used: 64, total: 200 },
    playerHistory: [12, 16, 14, 18, 21, 19, 17, 22, 25, 20, 28, 31, 27, 33, 29, 24, 30, 36, 32, 28, 25, 29, 24, 20],
  },

  /** ----------------------------------------------------------- TECH STACK */
  stack: ["Minecraft", "Paper", "GeyserMC", "Floodgate", "EconomyShopGUI", "GriefPrevention", "Linux", "Ubuntu", "Docker", "Nginx", "Discord", "Pterodactyl"],

  /** ------------------------------------------------------------ TESTIMONIALS */
  testimonials: { enabled: false, items: [] },

  /** ----------------------------------------------------------------- CONTACT */
  contact: {
    heading: "Have a Minecraft project in mind?",
    text: "Need help setting up a server, configuring plugins, planning cross-play, or exploring hosting? Get in touch and tell me what you're building.",
    email: "",
    discord: "Contact me on Discord",
    discordInvite: "",
    github: "",
    projectTypes: ["Minecraft server setup", "Plugin configuration", "Java + Bedrock cross-play", "Maps, scripts, configs, or models", "Hosting guidance", "Discord/community setup", "Something else"],
  },

  /** ------------------------------------------------------------------ FOOTER */
  footer: {
    description: "Personal Minecraft developer portfolio and SKYHOST & STUDIO — server projects, setup support, and hosting solutions in progress.",
    creditUrl: "#",
  },

  /** --------------------------------------------------------------------- SEO */
  seo: {
    title: "Prashant Thapa — Minecraft Developer | SKYHOST & STUDIO",
    description: "Minecraft server creator and developer portfolio featuring PHOENIX MC, NEXORA SMP, Java–Bedrock cross-play, and SKYHOST & STUDIO hosting services.",
    canonical: "https://example.com",
    ogImage: "",
  },
} as const;

export const navLinks = [
  { label: "Home", href: "#home" },
  { label: "About", href: "#about" },
  { label: "Skills", href: "#skills" },
  { label: "Services", href: "#services" },
  { label: "Projects", href: "#projects" },
  { label: "Experience", href: "#experience" },
  { label: "Contact", href: "#contact" },
];

export const projectFilters = ["All", "Server", "Plugin", "Network", "Website", "Infrastructure"] as const;
