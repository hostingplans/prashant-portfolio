import { Quote } from "lucide-react";

import { Reveal, Section, SectionHeading } from "@/components/site/primitives";
import { Terminal } from "@/components/site/Terminal";
import { siteConfig } from "@/config/site";

export function About() {
  return (
    <Section id="about">
      <SectionHeading eyebrow="About" title="The work behind a server that just stays up" />

      <div className="mt-12 grid gap-10 lg:grid-cols-[1.05fr_0.95fr] lg:gap-12">
        <div className="space-y-5">
          <Reveal>
            <p className="text-base leading-relaxed text-foreground">{siteConfig.about.intro}</p>
          </Reveal>
          {siteConfig.about.paragraphs.map((paragraph, index) => (
            <Reveal key={index} delay={60 * (index + 1)}>
              <p className="text-sm leading-relaxed text-muted-foreground sm:text-base">{paragraph}</p>
            </Reveal>
          ))}

          <Reveal delay={200}>
            <blockquote className="panel flex gap-3 p-5">
              <Quote className="mt-0.5 size-4 shrink-0 text-primary" aria-hidden="true" />
              <p className="text-sm leading-relaxed text-foreground">{siteConfig.about.philosophy}</p>
            </blockquote>
          </Reveal>
        </div>

        <Reveal delay={120} className="lg:pt-2">
          <Terminal />
          <dl className="mt-4 grid grid-cols-2 gap-3">
            {[
              { label: "Focus", value: "Performance & uptime" },
              { label: "Works with", value: "Paper · Velocity" },
              { label: "Based", value: siteConfig.location },
              { label: "Response", value: "Within 24h" },
            ].map((item) => (
              <div key={item.label} className="panel px-4 py-3">
                <dt className="label-mono">{item.label}</dt>
                <dd className="mt-1 text-sm text-foreground">{item.value}</dd>
              </div>
            ))}
          </dl>
        </Reveal>
      </div>
    </Section>
  );
}
