import { PixelMark, Reveal, Section, SectionHeading } from "@/components/site/primitives";
import { siteConfig } from "@/config/site";

export function Stats() {
  return (
    <section aria-label="Statistics" className="border-y border-border bg-surface/40">
      <dl className="mx-auto grid w-full max-w-6xl grid-cols-2 px-4 sm:px-6 lg:grid-cols-4 lg:px-8">
        {siteConfig.stats.map((stat, index) => (
          <Reveal
            key={stat.label}
            delay={index * 60}
            className="border-border px-2 py-8 text-center sm:py-10 lg:border-l lg:first:border-l-0"
          >
            <dd className="font-display text-3xl font-semibold text-foreground sm:text-4xl">{stat.value}</dd>
            <dt className="label-mono mt-2">{stat.label}</dt>
          </Reveal>
        ))}
      </dl>
    </section>
  );
}

export function TechStack() {
  return (
    <Section id="stack">
      <SectionHeading
        eyebrow="Stack"
        title="The technical stack"
        align="center"
        description="Edit this list in src/config/site.ts to match what you actually run."
      />

      <ul className="mx-auto mt-10 flex max-w-4xl flex-wrap justify-center gap-2.5">
        {siteConfig.stack.map((item, index) => (
          <Reveal
            as="li"
            key={item}
            delay={index * 30}
            className="flex items-center gap-2 rounded-sm border border-border bg-surface px-3.5 py-2 transition-colors hover:border-border-strong"
          >
            <PixelMark className="shrink-0" />
            <span className="font-mono text-xs text-foreground">{item}</span>
          </Reveal>
        ))}
      </ul>
    </Section>
  );
}

export function Testimonials() {
  if (!siteConfig.testimonials.enabled) return null;

  return (
    <Section id="testimonials" grid>
      <SectionHeading
        eyebrow="Testimonials"
        title="What people say"
        align="center"
        description="Placeholder quotes. Replace them with real feedback, or disable the section entirely."
      />

      <ul className="mt-12 grid gap-4 md:grid-cols-3">
        {siteConfig.testimonials.items.map((item, index) => (
          <Reveal as="li" key={index} delay={index * 70} className="panel flex flex-col p-5">
            <p className="flex-1 text-sm leading-relaxed text-foreground">&ldquo;{item.quote}&rdquo;</p>
            <div className="mt-5 flex items-center gap-3 border-t border-border pt-4">
              <span className="flex size-8 items-center justify-center rounded-sm border border-border bg-surface-2 font-mono text-[11px] text-muted-foreground">
                {item.author.slice(0, 2).toUpperCase()}
              </span>
              <div>
                <p className="text-sm font-medium">{item.author}</p>
                <p className="font-mono text-[11px] text-muted-foreground">{item.role}</p>
              </div>
            </div>
          </Reveal>
        ))}
      </ul>
    </Section>
  );
}
