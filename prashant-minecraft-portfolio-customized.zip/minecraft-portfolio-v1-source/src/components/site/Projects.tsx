import { ExternalLink, Github, Layers, X } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";

import { PixelMark, Reveal, Section, SectionHeading } from "@/components/site/primitives";
import { projectFilters, siteConfig, type Project } from "@/config/site";
import { cn } from "@/lib/utils";

export function Projects() {
  const [filter, setFilter] = useState<(typeof projectFilters)[number]>("All");
  const [active, setActive] = useState<Project | null>(null);

  const projects = useMemo(
    () => siteConfig.projects.filter((project) => filter === "All" || project.category === filter),
    [filter],
  );

  return (
    <Section id="projects" grid>
      <SectionHeading
        eyebrow="Projects"
        title="Selected work"
        description="Every entry below is an example project included with the template. Replace them with your own in src/config/site.ts."
      />

      <div className="mt-8 flex flex-wrap gap-2" role="tablist" aria-label="Filter projects">
        {projectFilters.map((option) => (
          <button
            key={option}
            type="button"
            role="tab"
            aria-selected={filter === option}
            onClick={() => setFilter(option)}
            className={cn(
              "rounded-sm border px-3 py-1.5 font-mono text-[11px] tracking-wide uppercase transition-colors",
              filter === option
                ? "border-primary bg-primary/12 text-primary"
                : "border-border text-muted-foreground hover:border-border-strong hover:text-foreground",
            )}
          >
            {option}
          </button>
        ))}
      </div>

      <ul className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {projects.map((project, index) => (
          <Reveal
            as="li"
            key={project.id}
            delay={index * 50}
            className="panel group flex flex-col overflow-hidden transition-[transform,border-color] duration-300 hover:-translate-y-0.5 hover:border-border-strong"
          >
            <button
              type="button"
              onClick={() => setActive(project)}
              aria-label={`Open ${project.name} case study`}
              className="relative aspect-16/9 w-full cursor-pointer overflow-hidden border-b border-border bg-surface-2 text-left focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
            >
              {project.image ? (
                <img
                  src={project.image}
                  alt={`${project.name} banner`}
                  loading="lazy"
                  width={1280}
                  height={720}
                  className="size-full object-cover transition-transform duration-500 group-hover:scale-[1.03]"
                />
              ) : (
                <div className="bg-grid flex size-full items-center justify-center opacity-90">
                  <PixelMark className="scale-[2.2]" />
                </div>
              )}
              <span className="absolute top-3 left-3 rounded-sm border border-border bg-background/85 px-2 py-1 font-mono text-[10px] tracking-wide uppercase backdrop-blur">
                {project.category}
              </span>
              <span className="absolute inset-0 flex items-center justify-center bg-background/70 opacity-0 transition-opacity duration-300 group-hover:opacity-100 group-focus-within:opacity-100">
                <span className="inline-flex items-center gap-1.5 rounded-sm border border-border-strong bg-surface px-3 py-1.5 font-mono text-[11px] tracking-wide uppercase">
                  <Layers className="size-3.5 text-primary" />
                  View Case Study
                </span>
              </span>
            </button>


            <div className="flex flex-1 flex-col p-5">
              <div className="flex items-center justify-between gap-3">
                <h3 className="text-base font-semibold">{project.name}</h3>
                <span className="font-mono text-[11px] text-muted-foreground">{project.date}</span>
              </div>
              <p className="mt-2 flex-1 text-sm leading-relaxed text-muted-foreground">{project.description}</p>

              <ul className="mt-4 flex flex-wrap gap-1.5">
                {project.tech.slice(0, 4).map((tech) => (
                  <li
                    key={tech}
                    className="rounded-sm border border-border bg-surface-2 px-1.5 py-0.5 font-mono text-[10px] text-muted-foreground"
                  >
                    {tech}
                  </li>
                ))}
              </ul>

              <div className="mt-5 flex flex-wrap items-center gap-2 border-t border-border pt-4">
                <button
                  type="button"
                  onClick={() => setActive(project)}
                  className="inline-flex items-center gap-1.5 rounded-sm bg-primary px-3 py-1.5 text-xs font-medium text-primary-foreground transition-colors hover:bg-primary-hover"
                >
                  <Layers className="size-3.5" />
                  Case Study
                </button>
                {project.links?.demo ? (
                  <a
                    href={project.links.demo}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1.5 rounded-sm border border-border px-3 py-1.5 text-xs transition-colors hover:bg-surface-2"
                  >
                    <ExternalLink className="size-3.5" />
                    Live Demo
                  </a>
                ) : null}
                {project.links?.github ? (
                  <a
                    href={project.links.github}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1.5 rounded-sm border border-border px-3 py-1.5 text-xs transition-colors hover:bg-surface-2"
                  >
                    <Github className="size-3.5" />
                    GitHub
                  </a>
                ) : null}
                <span className="ml-auto font-mono text-[10px] tracking-wide text-muted-foreground uppercase">
                  {project.status}
                </span>
              </div>
            </div>
          </Reveal>
        ))}
      </ul>

      {projects.length === 0 ? (
        <p className="mt-8 text-sm text-muted-foreground">No projects in this category yet.</p>
      ) : null}

      <ProjectModal project={active} onClose={() => setActive(null)} />
    </Section>
  );
}

function ProjectModal({ project, onClose }: { project: Project | null; onClose: () => void }) {
  const closeRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (!project) return;
    closeRef.current?.focus();
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [project, onClose]);

  if (!project) return null;
  const study = project.caseStudy ?? {};

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={`${project.name} case study`}
      className="fixed inset-0 z-60 flex items-start justify-center overflow-y-auto bg-background/80 p-4 backdrop-blur-sm sm:p-8"
      onClick={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
    >
      <div className="panel animate-in fade-in zoom-in-95 my-auto w-full max-w-3xl duration-200">
        <div className="sticky top-0 flex items-start justify-between gap-4 rounded-t-lg border-b border-border bg-surface px-5 py-4">
          <div>
            <p className="label-mono">
              {project.category} · {project.status} · {project.date}
            </p>
            <h3 className="mt-1 text-xl font-semibold">{project.name}</h3>
          </div>
          <button
            ref={closeRef}
            type="button"
            onClick={onClose}
            aria-label="Close case study"
            className="inline-flex size-9 shrink-0 items-center justify-center rounded-sm border border-border transition-colors hover:bg-surface-2"
          >
            <X className="size-4" />
          </button>
        </div>

        {project.image ? (
          <img
            src={project.image}
            alt={`${project.name} banner`}
            width={1280}
            height={720}
            className="aspect-16/9 w-full border-b border-border object-cover"
          />
        ) : null}

        <div className="space-y-6 px-5 py-6">
          {study.overview ? <p className="text-sm leading-relaxed text-foreground">{study.overview}</p> : null}

          <div className="grid gap-5 sm:grid-cols-2">
            {study.problem ? <Block title="Problem" text={study.problem} /> : null}
            {study.solution ? <Block title="Solution" text={study.solution} /> : null}
          </div>

          <div>
            <p className="label-mono">Technologies</p>
            <ul className="mt-2 flex flex-wrap gap-1.5">
              {project.tech.map((tech) => (
                <li
                  key={tech}
                  className="rounded-sm border border-border bg-surface-2 px-2 py-1 font-mono text-[11px] text-muted-foreground"
                >
                  {tech}
                </li>
              ))}
            </ul>
          </div>

          {study.architecture?.length ? <List title="Architecture" items={study.architecture} /> : null}
          {study.challenges?.length ? <List title="Challenges" items={study.challenges} /> : null}
          {study.results?.length ? <List title="Results" items={study.results} accent /> : null}

          {study.screenshots?.length ? (
            <div className="grid gap-3 sm:grid-cols-2">
              {study.screenshots.map((shot) => (
                <img
                  key={shot.src}
                  src={shot.src}
                  alt={shot.alt}
                  loading="lazy"
                  className="w-full rounded-sm border border-border"
                />
              ))}
            </div>
          ) : null}

          {project.links?.demo || project.links?.github ? (
            <div className="flex flex-wrap gap-2 border-t border-border pt-5">
              {project.links?.demo ? (
                <a
                  href={project.links.demo}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1.5 rounded-sm bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary-hover"
                >
                  <ExternalLink className="size-3.5" /> Live Demo
                </a>
              ) : null}
              {project.links?.github ? (
                <a
                  href={project.links.github}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1.5 rounded-sm border border-border px-4 py-2 text-sm transition-colors hover:bg-surface-2"
                >
                  <Github className="size-3.5" /> GitHub
                </a>
              ) : null}
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
}

function Block({ title, text }: { title: string; text: string }) {
  return (
    <div>
      <p className="label-mono">{title}</p>
      <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{text}</p>
    </div>
  );
}

function List({ title, items, accent = false }: { title: string; items: string[]; accent?: boolean }) {
  return (
    <div>
      <p className="label-mono">{title}</p>
      <ul className="mt-2 space-y-1.5">
        {items.map((item) => (
          <li key={item} className="flex gap-2 text-sm leading-relaxed text-muted-foreground">
            <span className={cn("mt-1.5 size-1.5 shrink-0", accent ? "bg-success" : "bg-primary")} aria-hidden="true" />
            {item}
          </li>
        ))}
      </ul>
    </div>
  );
}
