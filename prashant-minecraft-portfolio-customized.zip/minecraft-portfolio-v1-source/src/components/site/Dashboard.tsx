import { Cpu, HardDrive, MemoryStick, Users } from "lucide-react";

import { Reveal, Section, SectionHeading } from "@/components/site/primitives";
import { siteConfig } from "@/config/site";
import { cn } from "@/lib/utils";

const d = siteConfig.dashboard;

/** Tiny dependency-free area sparkline. */
function Sparkline({ values }: { values: readonly number[] }) {
  const max = Math.max(...values) || 1;
  const width = 600;
  const height = 140;
  const step = width / (values.length - 1);
  const points = values.map((value, index) => [index * step, height - (value / max) * (height - 12) - 6] as const);
  const line = points.map(([x, y], index) => `${index === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`).join(" ");
  const area = `${line} L${width},${height} L0,${height} Z`;

  return (
    <svg viewBox={`0 0 ${width} ${height}`} className="mt-4 h-36 w-full flex-1" role="img" aria-label="Player count over 24 hours">
      <defs>
        <linearGradient id="spark" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="var(--color-primary)" stopOpacity="0.35" />
          <stop offset="100%" stopColor="var(--color-primary)" stopOpacity="0" />
        </linearGradient>
      </defs>
      {[0.25, 0.5, 0.75].map((ratio) => (
        <line
          key={ratio}
          x1="0"
          x2={width}
          y1={height * ratio}
          y2={height * ratio}
          stroke="var(--color-border)"
          strokeWidth="1"
        />
      ))}
      <path d={area} fill="url(#spark)" />
      <path d={line} fill="none" stroke="var(--color-primary)" strokeWidth="2" strokeLinejoin="round" />
    </svg>
  );
}

function Meter({
  icon: Icon,
  label,
  value,
  percent,
}: {
  icon: typeof Cpu;
  label: string;
  value: string;
  percent: number;
}) {
  const tone = percent > 85 ? "bg-destructive" : percent > 65 ? "bg-warning" : "bg-success";
  return (
    <div className="panel p-4">
      <div className="flex items-center justify-between">
        <span className="label-mono flex items-center gap-2">
          <Icon className="size-3.5 text-muted-foreground" aria-hidden="true" />
          {label}
        </span>
        <span className="font-mono text-xs text-foreground">{value}</span>
      </div>
      <div className="mt-3 h-1.5 w-full overflow-hidden rounded-full bg-surface-2">
        <div className={cn("h-full rounded-full", tone)} style={{ width: `${Math.min(percent, 100)}%` }} />
      </div>
    </div>
  );
}

export function Dashboard() {
  const ramPercent = Math.round((d.ram.used / d.ram.total) * 100);
  const diskPercent = Math.round((d.disk.used / d.disk.total) * 100);
  const playerPercent = Math.round((d.players.online / d.players.max) * 100);

  return (
    <Section id="dashboard" grid>
      <SectionHeading
        eyebrow="Server Management"
        title="How I keep an eye on things"
        description="A visual dashboard component included with the template. The numbers are demo data — connect your own backend to make it live."
      />

      <Reveal className="mt-12 panel overflow-hidden">
        <div className="flex flex-wrap items-center gap-x-5 gap-y-2 border-b border-border px-5 py-4">
          <span className="flex items-center gap-2 font-mono text-sm">
            <span className="status-dot size-2 rounded-full bg-success" aria-hidden="true" />
            {d.serverName}
          </span>
          <span className="label-mono">{d.version}</span>
          <span className="label-mono">{d.proxy}</span>
          <span className="label-mono ml-auto">Uptime {d.uptime}</span>
        </div>

        <div className="grid gap-4 p-5 lg:grid-cols-[1.4fr_1fr]">
          <div className="panel flex flex-col p-4">
            <div className="flex items-end justify-between">
              <div>
                <p className="label-mono">Players online (24h)</p>
                <p className="mt-1 font-display text-2xl font-semibold">
                  {d.players.online}
                  <span className="text-base text-muted-foreground"> / {d.players.max}</span>
                </p>
              </div>
              <p className="font-mono text-xs text-success">TPS {d.tps.toFixed(1)}</p>
            </div>
            <Sparkline values={d.playerHistory} />
          </div>

          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-1">
            <Meter icon={Users} label="Slots used" value={`${playerPercent}%`} percent={playerPercent} />
            <Meter icon={Cpu} label="CPU" value={`${d.cpu}%`} percent={d.cpu} />
            <Meter
              icon={MemoryStick}
              label="Memory"
              value={`${d.ram.used} / ${d.ram.total} GB`}
              percent={ramPercent}
            />
            <Meter
              icon={HardDrive}
              label="Disk"
              value={`${d.disk.used} / ${d.disk.total} GB`}
              percent={diskPercent}
            />
          </div>
        </div>

        <p className="border-t border-border bg-surface-2 px-5 py-3 font-mono text-[11px] text-muted-foreground">
          # demo data · this component does not monitor a real server
        </p>
      </Reveal>
    </Section>
  );
}
