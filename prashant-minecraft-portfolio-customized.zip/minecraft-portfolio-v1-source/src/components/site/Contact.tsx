import { Github, Mail, MessageSquare, Send } from "lucide-react";
import { useState } from "react";

import { Reveal, Section } from "@/components/site/primitives";
import { siteConfig } from "@/config/site";
import { cn } from "@/lib/utils";

type Fields = { name: string; email: string; discord: string; type: string; message: string };
type Errors = Partial<Record<keyof Fields, string>>;

const EMPTY: Fields = { name: "", email: "", discord: "", type: "", message: "" };

function validate(values: Fields): Errors {
  const errors: Errors = {};
  if (values.name.trim().length < 2) errors.name = "Please enter your name.";
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(values.email.trim())) errors.email = "Please enter a valid email address.";
  if (!values.type) errors.type = "Pick a project type.";
  if (values.message.trim().length < 20) errors.message = "Tell me a bit more — at least 20 characters.";
  return errors;
}

export function Contact() {
  const [values, setValues] = useState<Fields>(EMPTY);
  const [errors, setErrors] = useState<Errors>({});
  const [submitted, setSubmitted] = useState(false);

  const set = (key: keyof Fields) => (event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setValues((previous) => ({ ...previous, [key]: event.target.value }));
    setErrors((previous) => ({ ...previous, [key]: undefined }));
    setSubmitted(false);
  };

  const onSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    const found = validate(values);
    setErrors(found);
    if (Object.keys(found).length === 0) setSubmitted(true);
  };

  const inputClass = (invalid?: string) =>
    cn(
      "w-full rounded-sm border bg-surface-2 px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground/70",
      invalid ? "border-destructive" : "border-border focus:border-border-strong",
    );

  return (
    <Section id="contact">
      <div className="grid gap-10 lg:grid-cols-[0.9fr_1.1fr] lg:gap-14">
        <div>
          <Reveal>
            <div className="flex items-center gap-2">
              <span className="h-px w-6 bg-primary" aria-hidden="true" />
              <span className="label-mono text-primary">Contact</span>
            </div>
            <h2 className="mt-4 text-3xl font-semibold sm:text-4xl">{siteConfig.contact.heading}</h2>
            <p className="mt-4 text-sm leading-relaxed text-muted-foreground sm:text-base">
              {siteConfig.contact.text}
            </p>
          </Reveal>

          <Reveal delay={80} className="mt-8 flex flex-col gap-3 sm:flex-row sm:flex-wrap lg:flex-col">
            <a
              href={siteConfig.contact.discordInvite || "#contact-form"}
              className="panel flex items-center gap-3 px-4 py-3 transition-colors hover:border-border-strong"
            >
              <MessageSquare className="size-4 text-primary" aria-hidden="true" />
              <span className="text-sm">
                Discord
                <span className="block font-mono text-[11px] text-muted-foreground">{siteConfig.contact.discord}</span>
              </span>
            </a>
            <a
              href={siteConfig.contact.github || "#contact-form"}
              className="panel flex items-center gap-3 px-4 py-3 transition-colors hover:border-border-strong"
            >
              <Github className="size-4 text-primary" aria-hidden="true" />
              <span className="text-sm">
                GitHub
                <span className="block font-mono text-[11px] text-muted-foreground">View my repositories</span>
              </span>
            </a>
            {siteConfig.contact.email ? (
              <a
                href={`mailto:${siteConfig.contact.email}`}
                className="panel flex items-center gap-3 px-4 py-3 transition-colors hover:border-border-strong"
              >
                <Mail className="size-4 text-primary" aria-hidden="true" />
                <span className="text-sm">
                  Email
                  <span className="block font-mono text-[11px] text-muted-foreground">{siteConfig.contact.email}</span>
                </span>
              </a>
            ) : null}
          </Reveal>
        </div>

        <Reveal delay={120}>
          <form id="contact-form" noValidate onSubmit={onSubmit} className="panel space-y-4 p-5 sm:p-6">
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Name" error={errors.name} htmlFor="field-name">
                <input
                  id="field-name"
                  value={values.name}
                  onChange={set("name")}
                  className={inputClass(errors.name)}
                  placeholder="Alex"
                  autoComplete="name"
                />
              </Field>
              <Field label="Email" error={errors.email} htmlFor="field-email">
                <input
                  id="field-email"
                  type="email"
                  value={values.email}
                  onChange={set("email")}
                  className={inputClass(errors.email)}
                  placeholder="you@example.com"
                  autoComplete="email"
                />
              </Field>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Discord username" htmlFor="field-discord" optional>
                <input
                  id="field-discord"
                  value={values.discord}
                  onChange={set("discord")}
                  className={inputClass()}
                  placeholder="username"
                />
              </Field>
              <Field label="Project type" error={errors.type} htmlFor="field-type">
                <select id="field-type" value={values.type} onChange={set("type")} className={inputClass(errors.type)}>
                  <option value="">Select…</option>
                  {siteConfig.contact.projectTypes.map((type) => (
                    <option key={type} value={type}>
                      {type}
                    </option>
                  ))}
                </select>
              </Field>
            </div>

            <Field label="Message" error={errors.message} htmlFor="field-message">
              <textarea
                id="field-message"
                rows={5}
                value={values.message}
                onChange={set("message")}
                className={cn(inputClass(errors.message), "resize-y")}
                placeholder="What's the server, what's happening, and what do you need help with?"
              />
            </Field>

            <button
              type="submit"
              className="inline-flex w-full items-center justify-center gap-2 rounded-sm bg-primary px-5 py-3 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary-hover sm:w-auto"
            >
              <Send className="size-4" />
              Validate &amp; copy details
            </button>

            <p aria-live="polite" className="font-mono text-[11px] leading-relaxed text-muted-foreground">
              {submitted
                ? "Looks good — but this template has no backend, so nothing was sent. Reach out via Discord or email above, or wire this form to your own email service."
                : "This is a frontend-only form: no message is sent anywhere until you connect an email service."}
            </p>
          </form>
        </Reveal>
      </div>
    </Section>
  );
}

function Field({
  label,
  htmlFor,
  error,
  optional,
  children,
}: {
  label: string;
  htmlFor: string;
  error?: string | undefined;
  optional?: boolean | undefined;
  children: React.ReactNode;
}) {
  return (
    <div>
      <label htmlFor={htmlFor} className="label-mono mb-2 block">
        {label}
        {optional ? <span className="normal-case"> (optional)</span> : null}
      </label>
      {children}
      {error ? <p className="mt-1.5 text-xs text-destructive">{error}</p> : null}
    </div>
  );
}
