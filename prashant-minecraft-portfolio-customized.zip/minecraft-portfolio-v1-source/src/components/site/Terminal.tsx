import { useEffect, useRef, useState } from "react";

const LINES: { label?: string; value?: string; text?: string }[] = [
  { text: "$ server status" },
  { label: "STATUS", value: "ONLINE" },
  { label: "PLAYERS", value: "128/500" },
  { label: "TPS", value: "20.0" },
  { label: "MEMORY", value: "5.8 / 8 GB" },
];

const PROMPT = "$ server status";

/** Decorative terminal panel with a light typing effect. Not a real console. */
export function Terminal() {
  const [typed, setTyped] = useState("");
  const [started, setStarted] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver((entries) => {
      if (entries.some((entry) => entry.isIntersecting)) {
        setStarted(true);
        observer.disconnect();
      }
    });
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!started) return;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduced) {
      setTyped(PROMPT);
      return;
    }
    let index = 0;
    const timer = window.setInterval(() => {
      index += 1;
      setTyped(PROMPT.slice(0, index));
      if (index >= PROMPT.length) window.clearInterval(timer);
    }, 55);
    return () => window.clearInterval(timer);
  }, [started]);

  const done = typed.length >= PROMPT.length;

  return (
    <div ref={ref} className="panel overflow-hidden font-mono text-[13px]">
      <div className="flex items-center justify-between border-b border-border bg-surface-2 px-4 py-2.5">
        <span className="label-mono">console</span>
        <span className="font-mono text-[11px] text-muted-foreground">decorative · demo output</span>
      </div>
      <div className="space-y-1.5 px-4 py-4">
        <p className="text-foreground">
          <span className="text-primary">{typed}</span>
          {!done ? <span className="caret text-primary">▌</span> : null}
        </p>
        <div
          className="space-y-1.5 transition-opacity duration-500"
          style={{ opacity: done ? 1 : 0 }}
          aria-hidden={!done}
        >
          {LINES.slice(1).map((line) => (
            <p key={line.label} className="flex gap-4">
              <span className="w-20 shrink-0 text-muted-foreground">{line.label}</span>
              <span className={line.value === "ONLINE" ? "text-success" : "text-foreground"}>{line.value}</span>
            </p>
          ))}
        </div>
      </div>
    </div>
  );
}
