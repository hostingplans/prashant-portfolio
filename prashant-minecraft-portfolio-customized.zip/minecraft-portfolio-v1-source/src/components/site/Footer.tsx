import { Github, Mail, MessageSquare } from "lucide-react";

import { PixelMark } from "@/components/site/primitives";
import { navLinks, siteConfig } from "@/config/site";

export function Footer() {
  return (
    <footer className="border-t border-border bg-surface/40">
      <div className="mx-auto grid w-full max-w-6xl gap-10 px-4 py-14 sm:px-6 lg:grid-cols-[1.4fr_1fr_1fr] lg:px-8">
        <div>
          <div className="flex items-center gap-2.5">
            <span className="flex size-8 items-center justify-center rounded-sm border border-border-strong bg-surface-2 font-mono text-xs text-primary">
              {siteConfig.initials}
            </span>
            <span className="font-display text-sm font-semibold">{siteConfig.name}</span>
          </div>
          <p className="mt-4 max-w-sm text-sm leading-relaxed text-muted-foreground">{siteConfig.footer.description}</p>
        </div>

        <nav aria-label="Footer">
          <p className="label-mono">Navigate</p>
          <ul className="mt-4 space-y-2">
            {navLinks.map((link) => (
              <li key={link.href}>
                <a href={link.href} className="text-sm text-muted-foreground transition-colors hover:text-foreground">
                  {link.label}
                </a>
              </li>
            ))}
          </ul>
        </nav>

        <div>
          <p className="label-mono">Elsewhere</p>
          <ul className="mt-4 space-y-2">
            <li>
              <a
                href={siteConfig.contact.github || "#contact"}
                className="inline-flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-foreground"
              >
                <Github className="size-4" aria-hidden="true" /> GitHub
              </a>
            </li>
            <li>
              <a
                href={siteConfig.contact.discordInvite || "#contact"}
                className="inline-flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-foreground"
              >
                <MessageSquare className="size-4" aria-hidden="true" /> Discord
              </a>
            </li>
            {siteConfig.contact.email ? (
              <li>
                <a
                  href={`mailto:${siteConfig.contact.email}`}
                  className="inline-flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-foreground"
                >
                  <Mail className="size-4" aria-hidden="true" /> {siteConfig.contact.email}
                </a>
              </li>
            ) : null}
          </ul>
        </div>
      </div>

      <div className="border-t border-border">
        <div className="mx-auto flex w-full max-w-6xl flex-col gap-3 px-4 py-5 sm:flex-row sm:items-center sm:justify-between sm:px-6 lg:px-8">
          <p className="font-mono text-[11px] text-muted-foreground">
            © {new Date().getFullYear()} {siteConfig.name}. All rights reserved.
          </p>
          <p className="flex items-center gap-2 font-mono text-[11px] text-muted-foreground">
            <PixelMark />
            Made by{" "}
            <a href={siteConfig.footer.creditUrl} className="text-foreground transition-colors hover:text-primary">
              Electro
            </a>
          </p>
        </div>
      </div>
    </footer>
  );
}
