import { ArrowUpRight, ChevronDown, Code2, Gauge, Network, Plug, Server, Wrench } from "lucide-react";
import { useState, type ComponentType } from "react";

import { Reveal, Section, SectionHeading } from "@/components/site/primitives";
import { siteConfig } from "@/config/site";
import { cn } from "@/lib/utils";

const ICONS: Record<string, ComponentType<{ className?: string }>> = {
  server: Server,
  gauge: Gauge,
  plug: Plug,
  network: Network,
  wrench: Wrench,
  code: Code2,
};

export function Services() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <Section id="services">
      <SectionHeading
        eyebrow="Services"
        title="What I can take off your hands"
        description="Scope and pricing are placeholders. Adjust the copy, or turn prices off entirely with showPricing: false."
      />

      <ul className="mt-12 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {siteConfig.services.map((service, index) => {
          const Icon = ICONS[service.icon] ?? Server;
          const open = openIndex === index;
          return (
            <Reveal
              as="li"
              key={service.title}
              delay={index * 60}
              className="panel flex flex-col p-5 transition-[transform,border-color] duration-300 hover:-translate-y-0.5 hover:border-border-strong"
            >
              <div className="flex items-start justify-between gap-3">
                <span className="flex size-9 items-center justify-center rounded-sm border border-border bg-surface-2">
                  <Icon className="size-4 text-primary" />
                </span>
                {siteConfig.showPricing ? (
                  <span className="font-mono text-[11px] text-muted-foreground">{service.price}</span>
                ) : null}
              </div>

              <h3 className="mt-4 text-base font-semibold">{service.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{service.description}</p>

              <button
                type="button"
                onClick={() => setOpenIndex(open ? null : index)}
                aria-expanded={open}
                className="mt-4 inline-flex items-center gap-1.5 self-start font-mono text-[11px] tracking-wide text-primary uppercase transition-opacity hover:opacity-80"
              >
                {open ? "Hide details" : "What's included"}
                <ChevronDown className={cn("size-3.5 transition-transform duration-300", open && "rotate-180")} />
              </button>

              <div
                className={cn(
                  "grid transition-all duration-300 ease-out",
                  open ? "mt-3 grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0",
                )}
              >
                <ul className="overflow-hidden border-l border-border pl-3 text-sm text-muted-foreground">
                  {service.details.map((detail) => (
                    <li key={detail} className="py-1 leading-relaxed">
                      {detail}
                    </li>
                  ))}
                </ul>
              </div>

              <a
                href="#contact"
                className="mt-5 inline-flex items-center gap-1.5 border-t border-border pt-4 text-sm font-medium transition-colors hover:text-primary"
              >
                Request this
                <ArrowUpRight className="size-3.5" />
              </a>
            </Reveal>
          );
        })}
      </ul>
    </Section>
  );
}
