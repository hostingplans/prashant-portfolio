import { ArrowRight, Mail } from "lucide-react";

import { PixelMark, Reveal } from "@/components/site/primitives";
import { siteConfig } from "@/config/site";
import { cn } from "@/lib/utils";

export function Hero() {
  return (
    <section id="home" className="relative overflow-hidden pt-28 pb-16 sm:pt-36 sm:pb-24">
      <div
        aria-hidden="true"
        className="bg-grid pointer-events-none absolute inset-0 opacity-50 [mask-image:radial-gradient(120%_80%_at_50%_0%,black,transparent_70%)]"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -top-24 left-1/2 h-72 w-[42rem] -translate-x-1/2 rounded-full bg-primary/12 blur-[120px]"
      />

      <div className="relative mx-auto grid w-full max-w-6xl gap-12 px-4 sm:px-6 lg:grid-cols-[1.15fr_0.85fr] lg:items-center lg:gap-10 lg:px-8">
        <div>
          {siteConfig.avatar ? (
            <Reveal className="mb-6 flex items-center gap-3">
              <img
                src={siteConfig.avatar}
                alt={`${siteConfig.name} profile picture`}
                width={96}
                height={96}
                className="size-14 shrink-0 rounded-sm border border-border-strong bg-surface-2 object-cover [image-rendering:pixelated] sm:size-16"
              />
              <span>
                <span className="block font-display text-base font-semibold sm:text-lg">{siteConfig.name}</span>
                <span className="label-mono">{siteConfig.role}</span>
              </span>
            </Reveal>
          ) : null}

          {siteConfig.available ? (

            <Reveal className="inline-flex items-center gap-2 rounded-full border border-border bg-surface px-3 py-1.5">
              <span className="status-dot size-1.5 rounded-full bg-success" aria-hidden="true" />
              <span className="font-mono text-[11px] tracking-wide text-muted-foreground uppercase">
                {siteConfig.availabilityLabel}
              </span>
            </Reveal>
          ) : null}

          <Reveal delay={60}>
            <h1 className="mt-6 text-4xl leading-[1.05] font-semibold sm:text-5xl lg:text-6xl">
              {siteConfig.role.split("&")[0]?.trim()}
              <span className="block text-primary">&amp; {siteConfig.role.split("&")[1]?.trim()}</span>
            </h1>
          </Reveal>

          <Reveal delay={120}>
            <p className="mt-6 max-w-xl text-base leading-relaxed text-muted-foreground">{siteConfig.tagline}</p>
          </Reveal>

          <Reveal delay={180} className="mt-8 flex flex-wrap items-center gap-3">
            <a
              href="#projects"
              className="inline-flex items-center gap-2 rounded-sm bg-primary px-5 py-3 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary-hover"
            >
              View My Work
              <ArrowRight className="size-4" />
            </a>
            <a
              href="#contact"
              className="inline-flex items-center gap-2 rounded-sm border border-border-strong px-5 py-3 text-sm font-medium transition-colors hover:bg-surface-2"
            >
              <Mail className="size-4" />
              Contact Me
            </a>
          </Reveal>

          <Reveal delay={240} className="mt-8 flex items-center gap-3 text-xs text-muted-foreground">
            <PixelMark />
            <span className="font-mono">{siteConfig.location}</span>
          </Reveal>
        </div>

        <Reveal delay={140}>
          <div className="panel overflow-hidden">
            <div className="flex items-center justify-between border-b border-border px-4 py-3">
              <span className="label-mono">Overview</span>
              <span className="flex gap-1.5" aria-hidden="true">
                <span className="size-2 rounded-full bg-border-strong" />
                <span className="size-2 rounded-full bg-border-strong" />
                <span className="size-2 rounded-full bg-primary/70" />
              </span>
            </div>
            <dl className="grid grid-cols-2">
              {siteConfig.heroPanel.map((item, index) => (
                <div
                  key={item.label}
                  className={cn(
                    "border-border px-4 py-5 sm:px-5 sm:py-6",
                    index % 2 === 0 && "border-r",
                    index < 2 && "border-b",
                  )}
                >
                  <dt className="label-mono">{item.label}</dt>
                  <dd
                    className={cn(
                      "mt-2 flex items-center gap-2 font-display text-xl font-semibold sm:text-2xl",
                      "accent" in item && item.accent && "text-success",
                    )}
                  >
                    {"accent" in item && item.accent ? (
                      <span className="status-dot size-2 rounded-full bg-success" aria-hidden="true" />
                    ) : null}
                    {item.value}
                  </dd>
                </div>
              ))}
            </dl>
            <p className="border-t border-border bg-surface-2 px-4 py-3 font-mono text-[11px] text-muted-foreground">
              # placeholder values — edit src/config/site.ts
            </p>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
