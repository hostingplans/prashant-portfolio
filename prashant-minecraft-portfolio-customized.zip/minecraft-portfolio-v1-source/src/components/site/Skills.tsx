import { Boxes, Code2, Database, Server } from "lucide-react";

import { Reveal, Section, SectionHeading } from "@/components/site/primitives";
import { siteConfig } from "@/config/site";

const ICONS = [Server, Code2, Boxes, Database];

export function Skills() {
  return (
    <Section id="skills" grid>
      <SectionHeading
        eyebrow="Skills"
        title="Tools I work with day to day"
        description="These are example skill groups shipped with the template — edit or remove anything you don't actually use in src/config/site.ts."
      />

      <ul className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {siteConfig.skills.map((group, index) => {
          const Icon = ICONS[index % ICONS.length]!;
          return (
            <Reveal as="li" key={group.category} delay={index * 70} className="panel flex flex-col p-5">
              <span className="flex size-9 items-center justify-center rounded-sm border border-border bg-surface-2">
                <Icon className="size-4 text-primary" aria-hidden="true" />
              </span>
              <h3 className="mt-4 text-base font-semibold">{group.category}</h3>
              <ul className="mt-4 flex flex-wrap gap-2">
                {group.items.map((item) => (
                  <li
                    key={item}
                    className="rounded-sm border border-border bg-surface-2 px-2 py-1 font-mono text-[11px] text-muted-foreground"
                  >
                    {item}
                  </li>
                ))}
              </ul>
            </Reveal>
          );
        })}
      </ul>
    </Section>
  );
}
