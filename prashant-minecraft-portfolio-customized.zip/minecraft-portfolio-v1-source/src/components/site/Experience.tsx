import { Reveal, Section, SectionHeading } from "@/components/site/primitives";
import { siteConfig } from "@/config/site";

export function Experience() {
  return (
    <Section id="experience">
      <SectionHeading
        eyebrow="Experience"
        title="Where I've worked"
        description="Demo timeline entries. Swap them for your own roles — no fabricated employment is included."
      />

      <ol className="mt-12 space-y-4">
        {siteConfig.experience.map((item, index) => (
          <Reveal as="li" key={`${item.role}-${index}`} delay={index * 70} className="relative pl-8 sm:pl-10">
            <span
              aria-hidden="true"
              className="absolute top-2 left-[6px] h-full w-px bg-border last:hidden"
              style={{ display: index === siteConfig.experience.length - 1 ? "none" : undefined }}
            />
            <span
              aria-hidden="true"
              className="absolute top-1.5 left-0 size-3 rounded-sm border border-primary bg-background"
            >
              <span className="absolute inset-[3px] bg-primary" />
            </span>

            <div className="panel p-5">
              <div className="flex flex-wrap items-baseline justify-between gap-2">
                <h3 className="text-base font-semibold">
                  {item.role}
                  <span className="text-muted-foreground"> · {item.org}</span>
                </h3>
                <span className="font-mono text-[11px] text-muted-foreground">{item.period}</span>
              </div>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{item.description}</p>

              <ul className="mt-4 space-y-1.5">
                {item.responsibilities.map((responsibility) => (
                  <li key={responsibility} className="flex gap-2 text-sm text-muted-foreground">
                    <span className="mt-1.5 size-1.5 shrink-0 bg-primary" aria-hidden="true" />
                    {responsibility}
                  </li>
                ))}
              </ul>

              <ul className="mt-4 flex flex-wrap gap-1.5">
                {item.tech.map((tech) => (
                  <li
                    key={tech}
                    className="rounded-sm border border-border bg-surface-2 px-1.5 py-0.5 font-mono text-[10px] text-muted-foreground"
                  >
                    {tech}
                  </li>
                ))}
              </ul>
            </div>
          </Reveal>
        ))}
      </ol>
    </Section>
  );
}
